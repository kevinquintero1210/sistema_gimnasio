
package sistema_gimnasio;

import sistema_gimnasio.vista.inicio;

/**
 *
 * @author Charly Cimino
 * Aprendé más Java en mi canal: https://www.youtube.com/c/CharlyCimino
 * Encontrá más código en mi repo de GitHub: https://github.com/CharlyCimino
 */
public class Sistema_gimnasio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        inicio meth = new inicio();
        meth.setVisible(true);
        // TODO code application logic here
    }

}
